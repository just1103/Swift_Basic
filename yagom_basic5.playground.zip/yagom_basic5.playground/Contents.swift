import UIKit

// 함수

func sumFunction(a: Int, b: Int) -> Int {
    return a+b
}

var sumResult: Int = sumFunction(a: 1, b: 2)
print(sumResult)

// closure

var sum: (Int, Int) -> Int = { (a: Int, b: Int) -> Int in
    return a+b
}

sumResult = sum(3,4)
print(sumResult)

// closure 할당한 변수에 다시 함수를 할당할 수 있다.
// sum = sumFunction(a:5,b:6) // yagom 강의 틀린점 - (Int,Int) 타입에 (Int)를 넣을수 없다!
//sumResult = sum (5,6)
// print(sumResult)

// 전달인자 기능

let add: (Int, Int) -> Int
add = { (a: Int, b: Int) -> Int in
    return a+b
}

let substract: (Int, Int) -> Int
substract = { (a: Int, b: Int) -> Int in
    return a-b
}

func calculate(a: Int, b: Int, method: (Int, Int) -> Int) -> Int {
    return method(a,b)
}
    
print(calculate(a: 1, b: 2, method: add))
print(calculate(a: 10, b: 5, method: substract))

var end: Int = calculate(a: 1, b: 2, method: add)
print(end, "확인용")  // 3 확인용 출력

//따로 클로저를 상수/변수에 넣어 전달하지 않고,
//함수를 호출할 때 클로저를 작성하여 전달할 수도 있습니다.

var calculated: Int

calculated = calculate(a: 50, b: 10, method:{ (left: Int, right: Int) -> Int in
    return left+right
})
                        
print(calculated) // 60

// closure 고급

var result: Int

result = calculate(a: 100, b: 99, method: {
    $0 + $1
})

print(result)


// Property


