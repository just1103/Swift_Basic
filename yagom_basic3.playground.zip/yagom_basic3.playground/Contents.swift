import UIKit

// Class

class Sample {
    var mutable: Int = 100
    let immutable: Int = 100
    
    static var typeProperty: Int = 100
    
    func instanceMethod() {
        print("instance Method 이다")
    }
    
    static func typeMethod() {  // 상속시 재정의 불가
        print("type Method-static 이다")
    }
    
    class func classMethod() {  // 상속시 재정의 가능
        print("type Method-class 이다")
    }
}

var mutableReference: Sample = Sample()

mutableReference.mutable = 200
// mutableReference.immutable = 200 // error

let immutableReference: Sample = Sample()

immutableReference.mutable = 200
// immutableReference.immutable = 200 // error

Sample.typeProperty = 200
Sample.typeMethod()
Sample.classMethod()

// Class 활용

class Student {
    var name: String = "unknown"
    var `class`: String = "Swift"
    
    class func selfIntro() {
        print("Student type의 class이다")
    }
    
    func selfIntro() {
        print("저는 \(self.class)반의 \(name)입니다")
    }
}

Student.selfIntro()

var yagom: Student = Student()
yagom.name = "yagom"
yagom.class = "스위프트"
yagom.selfIntro()

let jina: Student = Student()
jina.name = "jina"
jina.selfIntro()


// ex.

print("class로 만들기")

class Human {
    var name: String = "unknown"
    var time: Int = 0
    var hobby: String = "nothing"
    
    class func identity() {
        print("우리는 Human 타입이다")
    }
    
    func drink() {
        print("나 \(name) 물을 자주 마신다")
    }
    
    func intro() {
        print("나 \(name) \(time)살 때부터 \(hobby)을 해왔다")
    }
}

Human.identity()

var kevin: Human = Human()
kevin.name = "kevin"
kevin.time = 30
kevin.hobby = "코딩"
kevin.drink()
kevin.intro()

var hyosik: Human = Human()
hyosik.name = "hyosik"
hyosik.time = 35
hyosik.hobby = "비트코인"
hyosik.intro()

// enum

enum Weekday {
    case mon
    case tue
    case wed, thu, fri, sat, sun
}

var day: Weekday = Weekday.mon
day = .tue
day = .fri
print(day)

switch day {
case .mon, .tue, .wed, .thu:
    print("work, work, work")
case .fri:
    print("TGIF")
default:
    print("Holy Weekends")
}

enum Fruit: Int {
    case apple
    case pear
    case banana
}

print(Fruit.pear.rawValue)

//

enum Month {
    case dec, jan, feb
    case mar, apr, may
    case jun, jul, aug
    case sep, oct, nov
    
    func printMessage() {
        switch self {
        case .mar, .apr, .may:
            print("따스한 봄~")
        case .jun, .jul, .aug:
            print("여름 더워요~")
        case .sep, .oct, .nov:
            print("가을은 독서의 계절!")
        case .dec, .jan, .feb:
            print("추운 겨울입니다")
        }
    }
}

Month.mar.printMessage()
