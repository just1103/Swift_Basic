// Error

enum VendingMachineError: Error {
    case invalidInput
    case insufficientFunds(moneyNeeded: Int)
    case outOfStock
}

class VendingMachine {
    let itemPrice: Int = 100
    var itemCount: Int = 5
    var deposited: Int = 0
    
    // 돈 받기 메서드
    func receiveMoney(_ money: Int) throws {
        
        // 입력한 돈이 0 이하이면 오류를 던진다.
        guard money > 0 else {
            throw VendingMachineError.invalidInput
        }
        
        self.deposited += money
        print("\(money)원 받음")
    }
    
    // 물건 팔기 메서드
    func vend(numberOfItems numberOfItemsToVend: Int) throws -> String {
        
        // 원하는 아이템의 수량이 잘못 입력되었으면 오류를 던진다.
        guard numberOfItemsToVend > 0 else {
            throw VendingMachineError.invalidInput
        }
        
        // 구매하려는 수량보다 미리 넣어둔 돈이 적으면 오류를 던진다.
        guard numberOfItemsToVend * itemPrice <= deposited else {
            let moneyNeeded: Int
            moneyNeeded = numberOfItemsToVend * itemPrice - deposited
            
            throw VendingMachineError.insufficientFunds(moneyNeeded: moneyNeeded)
        }
        
        // 구매하려는 수량보다 요구하는 수량이 많으면 오류를 던진다. (재고 없음)
        guard itemCount >= numberOfItemsToVend else {
            throw VendingMachineError.outOfStock
        }
        
        let totalPrice = numberOfItemsToVend * itemPrice
        
        self.deposited -= totalPrice
        self.itemCount -= numberOfItemsToVend
        
        return "\(numberOfItemsToVend)개 제공함"
    }
}

let machine = VendingMachine()  // 인스턴스 생성

var result: String?  // 함수 return 값용 변수 생성


// do-catch

//do {
//    try machine.receiveMoney(0)
//} catch VendingMachineError.invalidInput {
//    print("입력 오류입니다.")
//} catch VendingMachineError.insufficientFunds(let moneyNeeded) {
//    print("\(moneyNeeded)원이 부족합니다.")
//} catch VendingMachineError.outOfStock {
//    print("수량이 부족합니다.")
//}
//// 입력 오류입니다. - 출력
//
//do {
//    try machine.receiveMoney(300)
//} catch {
//    switch error {
//    case VendingMachineError.invalidInput:
//        print("입력 오류입니다.")
//    case VendingMachineError.insufficientFunds(let moneyNeeded):
//        print("\(moneyNeeded)원이 부족합니다.")
//    case VendingMachineError.outOfStock:
//        print("수량이 부족합니다.")
//    default:
//        print("알 수 없는 오류 \(error)")
//    }
//}

//do {
//    result = try machine.vend(numberOfItems: 4)
//} catch {
//    print(error)
//}
//// insufficientFunds(moneyNeeded: 400)  // ?? guard 내용이 자동으로 넘어온건가?
//
//
//do {
//    result = try machine.vend(numberOfItems: 4)
//}

try machine.receiveMoney(300)
result = try? machine.vend(numberOfItems: 2)
result // 2개 제공함 - 출력
print(result) // Optional("2개 제공함") - 출력

//result = try? machine.vend(numberOfItems: 2)
//print(result) // nil - 출력

try machine.receiveMoney(100)
result = try! machine.vend(numberOfItems: 2)
result // 2개 제공함 - 출력
print(result) // Optional("2개 제공함") - 출력 왜지??
print(result!)

//result = try! machine.vend(numberOfItems: 1)
//// 런타임 오류 발생!

