import UIKit


var integers: Array<Int> = []
integers.append(1)
integers.append(100)
integers.append(1000)

integers

integers.contains(100)
integers.contains(99)

integers[0]
integers[1]

integers.remove(at: 0)
integers

integers[0]

var doubles: Array<Double> = [Double]()

var strings: [String] = [String]()

var characters: [Character] = []

let immutableArray = [1,2,3]


var anyDictionary: Dictionary<String,Any> = [String: Any]()
anyDictionary["someKey"] = "value"
anyDictionary["anotherKey"] = "100"

anyDictionary

anyDictionary.removeValue(forKey: "someKey")
anyDictionary

anyDictionary["someKey2"] = "value2"
anyDictionary

anyDictionary["someKey2"] = nil
anyDictionary


let emptyDictionary: [String: String] = [:]

let initializedDictionary: Dictionary<String, String> = ["name": "yagom", "gender": "male"]
initializedDictionary


var integerSet: Set<Int> = Set<Int>()
integerSet.insert(1)
integerSet.insert(100)
integerSet.insert(99)
integerSet.insert(99)
integerSet.insert(99)

integerSet

integerSet.contains(1)
integerSet.contains(2)

integerSet.remove(100)
integerSet
integerSet.insert(2)
integerSet.insert(3)
integerSet.insert(4)
integerSet
integerSet
integerSet

integerSet.removeFirst()
integerSet

let setA: Set<Int> = [1,2,3,4,5]
let setB: Set<Int> = [3,4,5,6,7]

let union: Set<Int> = setA.union(setB)
print(union)

let sortedUnion: [Int] = union.sorted()
print(union)

let intersection: Set<Int> = setA.intersection(setB)
print(intersection)

let subtracting: Set<Int> = setA.subtracting(setB)
print(subtracting)

// Function

func sum(a: Int, b: Int) -> Int {
    return a+b
}

sum(a: 1, b: 3)

func printMyName(name: String) -> Void {
    print(name)
}

printMyName(name: "kevin")

func hello() {
    print("Hello!")
}

hello()

// Function 2

func greeting(friend: String, me: String = "yagom"){
    print("Hello \(friend)! I'm \(me)")
}

greeting(friend: "hana")
greeting(friend: "john", me: "eric")

// func greeting(to friend: String, from me: String) {
//    print("Hello \(friend)! I'm \(me)")
// }

// greeting(to: "hana", from: "yagom")
// greeting(friend: "Why", me: "not")
// greeting(friend: "Why", me: "not") possible

func sayHelloToFriends(me: String, friends: String...) -> String {
    return "Hello \(friends)! I'm \(me)!"
}

print(sayHelloToFriends(me: "yagom", friends: "hana", "kevin", "wing"))

print(sayHelloToFriends(me: "yagom", friends: "hana"))

print(sayHelloToFriends(me: "yagom"))


var someFunction: (String, String) -> Void = greeting(friend:me:)
someFunction("eric", "yagom")

func greeting2(friend: String, me: String) {
    print("Hello \(friend)!!! I'm \(me)!!!")
}
greeting2(friend: "1", me: "2")

someFunction = greeting2(friend:me:)
someFunction("3", "4")

var someFunction2: (String, String) -> Void = greeting2(friend:me:)
someFunction2("eric","yagom")

var someFuntion3: (String, String) -> Void = greeting(friend:me:)
someFuntion3("1","2")

func runAnother(myParameters: (String, String) -> Void) {
    myParameters("jenny", "mike")
}

runAnother(myParameters: someFuntion3)

runAnother(myParameters: greeting(friend:me:))

// runAnother(myParameters: someFuntion3)


func sumA(a: Int, b: Int) {
    print(a+b)
}
sumA(a:1,b:2)  // 3 출력

func multA(a: Int, b: Int) {
        print(a*b)
}
multA(a:3, b:4) // 12 출력

func parametersDataTypeFunc(testParameters: (Int, Int) -> Void) {
    testParameters(10,20)
}

parametersDataTypeFunc(testParameters: sumA(a:b:))  // 30 출력
parametersDataTypeFunc(testParameters: multA(a:b:)) // 200 출력

// sumA(testParameters)  // 이건 불가
// sumA(parametersDataTypeFunc(testParameters: <#T##(Int, Int) -> Void#>))  // 이것도 불가 sumA의 매개변수 type은 Int 여야 하므로


// condition

let someInteger = -100

if someInteger < 100 {
    print("100 미만")
} else if someInteger > 100 {
    print("100 초과")
} else {
    print("100")
} // 100

print("check switch")

switch someInteger {
case 0:
    print("Zero")
case 1..<100:
    print("1~99")
case 100:
    print("100")
case 101...Int.max:
    print("Over 100")
default:
    print("Unknown")
}

switch "jake" {
case "jake":
    print("jake")
    fallthrough
case "mina":
    print("mina")
case "yagom", "minho":
    print("yagom!!")
default:
    print("unknown")
} // yagom!!
