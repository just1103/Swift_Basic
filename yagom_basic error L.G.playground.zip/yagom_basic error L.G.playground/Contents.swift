enum VendingMachineError: Error {
    case invalidSelection
    case insufficientFunds(coinsNeeded: Int)
    case outOfStock
}

struct Item { // 자판기에 들어갈 item의 구조체 정의
    var price: Int
    var count: Int
}

class VendingMachine {  // 클래서 생성
    var inventory = [ // 이게 dictionary 인가? (이것도 변수니까 저장 프로퍼티?)
        "Candy Bar": Item(price: 12, count: 7),
        "Chips": Item(price: 10, count: 4),
        "Pretzels": Item(price: 7, count: 11)
    ]
    var coinsDeposited = 0
    
    func vend(itemNamed name: String) throws {  // 메서드 정의
        guard let item = inventory[name] else {  // inventory[name] - 프로퍼티 inventory + 메서드 vend의 parameter ?? 이게 name이 <snack의 name>인지 어떻게 알지? 정의 안해줬는데
            throw VendingMachineError.invalidSelection
        }
        
        guard item.count > 0 else { // *복습) if-let 구문과 달리 guard-let의 item 변수는 구문 밖에서도 활용 가능함
            throw VendingMachineError.outOfStock
        }
        
        guard item.price <= coinsDeposited else {
            throw VendingMachineError.insufficientFunds(coinsNeeded: item.price - coinsDeposited)
        }
        
        coinsDeposited -= item.price
        
        var newItem = item
        newItem.count -= 1
        inventory[name] = newItem
        
        print("Dispensing \(name)")
    }
}

let favoriteSnacks = [
    "Alice": "Chips",
    "Bob": "Licorice",
    "Eve": "Pretzels"
]

func buyFavoriteSnacks(person: String, vendingMachine: VendingMachine) throws {
    let snackName = favoriteSnacks[person] ?? "Candy Bar"  // favoriteSnacks[person] 이것도
    try vendingMachine.vend(itemNamed: snackName)
// Because the vend(itemNamed:) method can throw an error, it’s called with the try keyword in front of it.
}

// vend(itemNamed:) 메소드에서 발생한 에러는 buyFavoriteSnack(person:vendingMachine:) 함수가 실행되는 곳에까지 전해집니다.
// any errors that the vend(itemNamed:) method throws will propagate up to the point where the buyFavoriteSnack(person:vendingMachine:) function is called.


// Error Throwing initializers

struct PurchasedSnack {
    let name: String
    init (name: String, vendingMachine: VendingMachine) throws {
        try vendingMachine.vend(itemNamed: name)
        self.name = name
    }
}

// the initializer for the PurchasedSnack structure in the listing below calls a throwing function as part of the initialization process, and it handles any errors that it encounters by propagating them to its caller.
// PurchasedSnack 구조체의 초기자는 초기화 단계의 일부분으로써 에러를 발생시킬 수 있는 함수입니다. 그리고 초기자가 실행될 때 발생한 에러는 이 초기자를 호출한 곳에 전달 됩니다.


// 방법-1 the following code matches against all three cases of the VendingMachineError enumeration.
var vendingMachine = VendingMachine()
vendingMachine.coinsDeposited = 8
do {
    try buyFavoriteSnacks(person: "Alice", vendingMachine: vendingMachine) // buyFavoriteSnacks 함수는 오류 발생 여지가 있으므로 (can throw an error) try expression 에서 호출됨
    print("Success! Yum.")
} catch VendingMachineError.invalidSelection {
    print("Invalid Selection.")
} catch VendingMachineError.outOfStock {
    print("Out of Stock.")
} catch VendingMachineError.insufficientFunds(let coinsNeeded) {
    print("Insufficient Funds. Please insert an additional \(coinsNeeded) coins.")
} catch {
    print("Unexpected error: \(error).")
}
// Prints "Insufficient funds. Please insert an additional 2 coins."

// vendingMachine.coinsDeposited = 10
// Prints Dispensing Chips, Success! Yum. (오류가 발생하지 않은 경우)

// the buyFavoriteSnack(person:vendingMachine:) function is called in a try expression, because it can throw an error. If an error is thrown, execution immediately transfers to the catch clauses, which decide whether to allow propagation to continue.
// If no pattern is matched, the error gets caught by the final catch clause and is bound to a local error constant. (만약 발생한 에러 종류에 해당하는 catch pattern 가 없다면 에러는 마지막 catch 구문에 걸리게 되서 지역 에러 상수인 error로 처리할 수 있습니다.)
// If no error is thrown, the remaining statements in the do statement are executed.

// 방법-2
func nourish(with item: String) throws {
    do {
        try vendingMachine.vend(itemNamed: item)
    } catch is VendingMachineError {  // *is : Enum Error 3가지 경우에 해당하는지 체크
        print("Couldn't buy that from the the vending machine.") // Error가 발생했는데 Enum Error 3가지 경우에 해당하는 경우
    }
}

do {
    try nourish(with: "Beef-Flavored Chips")
} catch {
    print("Unexpected non-vending-machine-related error: \(error)") // Error가 발생했는데 Enum Error 3가지 경우에 해당하지 않는 경우
}

// The catch clauses don’t have to handle every possible error that the code in the do clause can throw.
// For example, the above example can be written so any error that isn’t a VendingMachineError is instead caught by the calling function: (<자동판매기 오류가 아닌 오류>는 다음의 호출 기능에 의해 대신 잡힙니다.)

// In the nourish(with:) function, if vend(itemNamed:) throws an error that’s one of the cases of the VendingMachineError enumeration, nourish(with:) handles the error by printing a message.
// Otherwise, nourish(with:) propagates the error to its call site. (nourish 함수는 그것을 호출한 곳에 에러를 발생시킨다.) The error is then caught by the general catch clause.

// 방법-3

func eat(item: String) throws {
    do {
        try vendingMachine.vend(itemNamed: item)
    } catch VendingMachineError.invalidSelection, VendingMachineError.insufficientFunds, VendingMachineError.outOfStock {
        print("Invalid Selection, out of stock, or not enough money.")
    }
}

// Another way to catch several related errors is to list them after catch, separated by commas.
