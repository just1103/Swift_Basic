extension Int {
    var isEven: Bool {
      get{
                  return self % 2 == 0
            }
    }

    var isOdd: Bool {
      get{
            return self % 2 == 1
            }
    }
}

var number: Int = 3
print(number.isEven) // false
print(number.isOdd) // true

number = 2
print(number.isEven) // true
print(number.isOdd) // false

extension Int {
    func multiply(by n: Int) -> Int {
        return self * n
    }
}

number = 3
print(number.multiply(by: 2))   // 6
print(number.multiply(by: 3))   // 9


print(3.multiply(by: 2))  // 6
print(4.multiply(by: 5))  // 20



extension String {
//    var intTypeNumber: Int = 0
//    var doubleTypeNumber: Double = 0.0
// 에러 메세지 - Extensions must not contain stored properties
    
    init(intTypeNumber: Int) {
        self = "\(intTypeNumber)"   // Int type의 입력값 (intTypeNumber)을 "String 타입"으로 변경해주는 기능
    }
    
    init(doubleTypeNumber: Double) {
        self = "\(doubleTypeNumber)"
    }
}

let stringFromInt: String = String(intTypeNumber: 100)
print(stringFromInt)

let stringFromDouble: String = String(doubleTypeNumber: 100.0)
print(stringFromDouble)


// nickname이 없는 경우가 있다면

class PersonC {
    var name: String
    var age: Int
    var nickName: String?
    
    convenience init(nameKeyIn: String, ageKeyIn: Int, nickNameKeyIn: String) {  // 위와 동일한 기능 수행
        self.init(nameKeyIn: nameKeyIn, ageKeyIn: ageKeyIn)  // type이 아니라 내용 (변수)가 들어감
       self.nickName = nickNameKeyIn
  }
  
    init(nameKeyIn: String, ageKeyIn: Int) {
        self.name = nameKeyIn
        self.age = ageKeyIn
    }
}

let kevin: PersonC = PersonC(nameKeyIn: "kevin", ageKeyIn: 10)
let mike: PersonC = PersonC(nameKeyIn: "mike", ageKeyIn: 15, nickNameKeyIn: "m")

print(kevin.name)
print(kevin.age)
// print(kevin.nickName)

extension String {
    init(intTypeNumber2: Int){
        self = "\(intTypeNumber2)"
    }
}

var kekevin = String(intTypeNumber2: 999)
print(kekevin)
