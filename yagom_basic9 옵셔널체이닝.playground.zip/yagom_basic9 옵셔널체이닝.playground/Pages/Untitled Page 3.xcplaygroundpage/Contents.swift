class Person {
    var name: String = ""
    func breath() {
        print("숨을 쉽니다")
    }
}
class Student: Person {  // subclass
    var school: String = ""
    func goToSchool() {
        print("등교를 합니다")
    }
}
class UniversityStudent: Student {  // subclass의 subclass
    var major: String = ""
    func goToMT() {
        print("멤버쉽 트레이닝을 갑니다 신남!")
    }
}
var yagom: Person = Person()
var hana: Student = Student()
var jason: UniversityStudent = UniversityStudent()

// 타입 확인

var result: Bool  // true or false로 결과값을 보여주는 용도

result = yagom is Person // true  // 인스턴스 yagom이 Person type인가? 맞으면 true
result = yagom is Student // false
result = yagom is UniversityStudent // false

result = hana is Person // true  // Student class는 Person class를 상속받아서 Person의 특성을 모두 가지고 있으므로 true
result = hana is Student // true
result = hana is UniversityStudent // false

result = jason is Person // true
result = jason is Student // true
result = jason is UniversityStudent // true

if yagom is UniversityStudent {
    print("yagom은 대학생입니다")
} else if yagom is Student {
    print("yagom은 학생입니다")
} else if yagom is Person {
    print("yagom은 사람입니다")
} // yagom은 사람입니다

switch yagom {
case is UniversityStudent:
    print("yagom is UniversityStudent")
case is Student:
    print("yagom is Student")
case is Person:  // 이 case에 해당되므로 print 실행
    print("yagom is Person")
default:
    print("error")
} // yagom is Person - 출력

switch jason {
case is UniversityStudent:
    print("jason은 대학생입니다")
case is Student:
    print("jason은 학생입니다")
case is Person:
    print("jason은 사람입니다")
default:
    print("jason은 사람도, 학생도, 대학생도 아닙니다")
} // jason은 대학생입니다 - 출력

// up casting

var mike: Person = UniversityStudent() as Person  // UniversityStudent 인스턴스를 생성하여 superclass Person 행세를 할 수 있도록 업 캐스팅

//var mike2: UniversityStudent = Person() as UniversityStudent // 컴파일 오류

var jina: Any = Person() as Any // as Any 생략가능  // Any type에 Person class가 들어갈 수 있다.

// down casting - as?

// var mike: Person = UniversityStudent() as Person // 1. mike는 Person type이지만, 실질적으로 UniversityStudent의 인스턴스이다.
var jenny: Student = Student()

-
var optionalCasted: Student?

optionalCasted = mike as? UniversityStudent  // 2. mike는 실질적으로 UniversityStudent의 인스턴스이므로 subclass UniversityStudent type으로 Casting 성공 ???

optionalCasted = jenny as? UniversityStudent // nil
// optionalCasted = jenny as? Student // always suceeds

optionalCasted = jina as? UniversityStudent // nil  // jina는 Person Type 이므로 Student 또는 UniversityStudent로 Casting 실패
optionalCasted = jina as? Student // nil

// down casting - as!

var forcedCasted: Student

forcedCasted = mike as! UniversityStudent
//forcedCasted = jenny as! UniversityStudent // 런타임 오류 // 강제로 UniversityStudent type이 되라고 명령했지만, 불가능해서 오류 발생
//forcedCasted = jina as! UniversityStudent // 런타임 오류
//forcedCasted = jina as! Student // 런타임 오류

// 활용

func doSomethingWithSwitch(someone: Person) {
    switch someone {  // someone으로 가져온 것이 어떤 type인지 확인하기 위한 switch case-is 구문
    case is UniversityStudent:
        (someone as! UniversityStudent).goToMT()  // 확인 결과 해당 값을 가져오려면 다시 down casting 해줘야 한다.
    case is Student:
        (someone as! Student).goToSchool()
    default:
        (someone ).breath()
    }
}

doSomethingWithSwitch(someone: mike as Person) // 멤버쉽 트레이닝을 갑니다 신남!
doSomethingWithSwitch(someone: mike) // 멤버쉽 트레이닝을 갑니다 신남!
doSomethingWithSwitch(someone: jenny) // 등교를 합니다
doSomethingWithSwitch(someone: yagom) // 숨을 쉽니다

-
func doSomething(someone: Person) {
    if let universityStudent = someone as? UniversityStudent {  // switch 대신 if-let을 쓰면 as?를 통해 casting 함과 동시에 unwrapping (옵셔널 추출)해서 값을 가져올 수 있다.
        universityStudent.goToMT()
    } else if let student = someone as? Student {
        student.goToSchool()
    } else {
        self.breath()
    }
}

doSomething(someone: mike as Person) // 멤버쉽 트레이닝을 갑니다 신남!
doSomething(someone: mike) // 멤버쉽 트레이닝을 갑니다 신남!
doSomething(someone: jenny) // 등교를 합니다
doSomething(someone: yagom) // 숨을 쉽니다
