// 예제 클래스
// 사람 클래스
class Person {
    var name: String
    var job: String?  // optional type의 default값은 nil 이다.
    var home: Apartment?  // optional type의 default값은 nil 이다.
    
    init(name: String) {
        self.name = name
    }
}
// 사람이 사는 집 클래스
class Apartment {
    var buildingNumber: String
    var roomNumber: String
    var `guard`: Person?
    var owner: Person?
    
    init(dong: String, ho: String) {  // 여기서 변수 dong, ho가 선언된건가?
        buildingNumber = dong  // 인스턴스 초기화 단계에서의 할당값 (dong, ho의 입력값)이 변수 buildingNumber로 들어간다 ???
        roomNumber = ho
    }
}

// 옵셔널 체이닝 사용
let yagom: Person? = Person(name: "yagom")
let apart: Apartment? = Apartment(dong: "101", ho: "202")
let superman: Person? = Person(name: "superman")
// 옵셔널 체이닝이 실행 후 결과값이 nil일 수 있으므로 결과 타입도 옵셔널입니다

// 만약 우리집의 경비원의 직업이 궁금하다면..?
// *옵셔널 체이닝을 사용하지 않는 경우
func guardJob(owner: Person?) { // 여러 번 optional binding으로 unwrapping 해야 해서 번거로움
    if let owner = owner {  // owner라는 프로퍼티 (optional type)를 unwrapping 해서 값을 다시 owner에 할당하겠다? (nil이면 할당 안하고)
        if let home = owner.home {
            if let `guard` = home.guard {
                if let guardJob = `guard`.job {
                    print("우리집 경비원의 직업은 \(guardJob)입니다")
                } else {
                    print("우리집 경비원은 직업이 없어요")
                }
            }
            else { print("owner, home, guard, job 중에 nil이 있어요") } // nil 일 때 statements도 따로 지정해야 해서 번거로움
        }
        else { print("owner, home, guard, job 중에 nil이 있어요") }
    }
    else { print("owner, home, guard, job 중에 nil이 있어요") }
}
guardJob(owner: yagom) // owner, home, guard, job 중에 nil이 있어요 - 출력

// *옵셔널 체이닝을 사용하는 경우
func guardJobWithOptionalChaining(owner: Person?) {
    if let guardJob = owner?.home?.guard?.job { // owner가 있나? -> home이 있나? -> guard가 있나? -> (if let) job이 있나? 차례로 nil check
        print("우리집 경비원의 직업은 \(guardJob)입니다")
    } else {
        print("우리집 경비원은 직업이 없어요") // 하나만 nil 이어도 else block이 출력됨
    }
}
guardJob(owner: yagom) // 출력 안됨
guardJobWithOptionalChaining(owner: yagom) // 우리집 경비원은 직업이 없어요 - 출력

if yagom?.home == nil {
    print("yagom은 home이 없다")
} // (확인용) yagom은 home이 없다 - 출력


yagom?.home?.guard?.job // nil (yagom은 home이 없는 상태이므로)
yagom?.home = apart  // **apart 인스턴스를 할당해줌
yagom?.home // Optional(Apartment)

yagom?.home?.guard // nil (guard가 없는 상태이므로)
yagom?.home?.guard = superman // **superman 인스턴스를 할당해줌
yagom?.home?.guard // Optional(Person)
yagom?.home?.guard?.name // superman (superman 인스턴스의 초기값이 이미 들어가있음)
yagom?.home?.guard?.job // nil
yagom?.home?.guard?.job = "경비원2" // superman 직업을 할당해줌

guardJob(owner: yagom) // 우리집 경비원의 직업은 경비원2입니다 - 출력
guardJobWithOptionalChaining(owner: yagom) // 우리집 경비원의 직업은 경비원2입니다 - 출력

// nil 병합 연산자 "??"

var guardJob: String
    
guardJob = yagom?.home?.guard?.job ?? "슈퍼맨" // "yagom?.home?.guard?.job" 이 중에서 nil이 있으면 변수 guardJob에 "슈퍼맨"을 할당해라.
print(guardJob) // 경비원2 (nil이 아니므로 본래 값 출력)

yagom?.home?.guard?.job = nil // job에 nil을 할당
guardJob = yagom?.home?.guard?.job ?? "슈퍼맨"
print(guardJob) // 슈퍼맨 (nil이므로 ??가 작동함)
