class Person {
    var name: String
    var job: String?  // optional type의 default값은 nil 이다.
    var home: Apartment?  // optional type의 default값은 nil 이다.
    
    init(name: String) {
        self.name = name
    }
}


// 사람이 사는 집 클래스
class Apartment {
    var buildingNumber: String
    var roomNumber: String
    var `guard`: Person?
    var owner: Person?
    
    init(dong2 : String, ho2 : String) {  // argument label
        buildingNumber = dong2  // 인스턴스 초기화 단계에서의 할당값 (dong, ho의 입력값)이 변수 buildingNumber로 들어간다!!!
        roomNumber = ho2
    }
}

// 옵셔널 체이닝 사용
let yagom: Person? = Person(name: "yagom")
let apart: Apartment? = Apartment(dong2: "101", ho2: "202")
let superman: Person? = Person(name: "superman")
// (의도) 옵셔널 체이닝이 실행 후 결과값이 nil일 수 있으므로 결과 타입도 옵셔널입니다. (init? 이 아닌데도???)

// 만약 우리집의 경비원의 직업이 궁금하다면..?
// *옵셔널 체이닝을 사용하지 않는 경우
func guardJob(owner: Person?) { // 여러 번 optional binding으로 unwrapping 해야 해서 번거로움
    if let owner = owner {  // owner라는 프로퍼티 (optional type)를 unwrapping 해서 값을 다시 owner에 할당하겠다? (nil이면 할당 안하고)
        if let home = owner.home {
            if let `guard` = home.guard {
                if let guardJob = `guard`.job {
                    print("우리집 경비원의 직업은 \(guardJob)입니다")
                } else {
                    print("우리집 경비원은 직업이 없어요")
                }
            }
            else { print("owner, home, guard, job 중에 nil이 있어요") } // nil 일 때 statements도 따로 지정해야 해서 번거로움
        }
        else { print("owner, home, guard, job 중에 nil이 있어요") }
    }
    else { print("owner, home, guard, job 중에 nil이 있어요") }
}
guardJob(owner: yagom) // owner, home, guard, job 중에 nil이 있어요 - 출력

// 옵셔널 체이닝을 사용하는 경우? =>

func grardJobWithOptionalChaining(owner: Person?) {
    if let guardJob = owner?.home?.guard?.job {
        print("우리집 경비원의 직업은 \(guardJob) 입니다" )
    } else {
        print("우리집 경비원은 직업이 없어요")
    }
}

grardJobWithOptionalChaining(owner: yagom)

yagom?.home = apart
grardJobWithOptionalChaining(owner: yagom)

yagom?.home?.guard

yagom?.home?.guard = superman

yagom?.home?.guard?.name

yagom?.home?.guard?.job
yagom?.home?.guard?.job = "경비원2"
grardJobWithOptionalChaining(owner: yagom)

var guardjob: String

guardjob = yagom?.home?.guard?.job ?? "슈퍼맨"
print(guardjob)

yagom?.home?.guard?.job = nil
guardjob = yagom?.home?.guard?.job ?? "슈퍼맨"
print(guardjob)

yagom?.home?.guard = nil
guardjob = yagom?.home?.guard?.job ?? "슈퍼맨2"
print(guardjob)

// type casting

class PersonZ {
    var name: String = ""
    func breath() {
        print("숨을 쉽니다")
    }
}

class Student: PersonZ {  // subclass
    var school: String = ""
    func goToSchool() {
        print("등교를 합니다")
    }
}

class UniversityStudent: Student {  // subclass의 subclass
    var major: String = ""
    func goToMT() {
        print("멤버쉽 트레이닝을 갑니다 신남!")
    }
}

var yagomZ: PersonZ = PersonZ()
var hana: Student = Student()
var jason: UniversityStudent = UniversityStudent()

var result: Bool

result = yagomZ is PersonZ
result = yagomZ is Student
result = yagomZ is UniversityStudent

result = jason is PersonZ
result = jason is Student
result = jason is UniversityStudent

switch yagomZ {
case is UniversityStudent:
    print("yagomZ is UniversityStudent")
case is Student:
    print("yagomZ is Student")
case is PersonZ:
    print("yagomZ is PersonZ")
default:
    print("error")
}

var mike: PersonZ = UniversityStudent() as PersonZ  // UniversityStudent 인스턴스를 생성하여 superclass Person 행세를 할 수 있도록 업 캐스팅

//var mike2: UniversityStudent = Person() as UniversityStudent // 컴파일 오류

var jina: Any = PersonZ() as Any // as Any 생략가능  // Any type에 Person class가 들어갈 수 있다.

var jenny: Student = Student()

var optionalCasted: Student?

optionalCasted = mike as? UniversityStudent  // 2. mike는 실질적으로 UniversityStudent의 인스턴스이므로 subclass UniversityStudent type으로 Casting 성공 ???

optionalCasted = jenny as? UniversityStudent // nil
optionalCasted = jenny as? Student // always suceeds

optionalCasted = jina as? UniversityStudent // nil  // jina는 Person Type 이므로 Student 또는 UniversityStudent로 Casting 실패
optionalCasted = jina as? Student // nil

// as!

var forcedCasted: Student

forcedCasted = mike as! UniversityStudent
//forcedCasted = jenny as! UniversityStudent // 런타임 오류 // 강제로 UniversityStudent type이 되라고 명령했지만, 불가능해서 오류 발생
//forcedCasted = jina as! UniversityStudent // 런타임 오류
//forcedCasted = jina as! Student // 런타임 오류

// 활용

func doSomethingWithSwitch(someone: PersonZ) {
    switch someone {  // someone으로 가져온 것이 어떤 type인지 확인하기 위한 switch case-is 구문
    case is UniversityStudent:
        (someone as! UniversityStudent).goToMT()  // 확인 결과 해당 값을 가져오려면 다시 down casting 해줘야 한다.
    case is Student:
        (someone as! Student).goToSchool()
    case is PersonZ:
        (someone as! PersonZ).breath()
    }
}

doSomethingWithSwitch(someone: mike as PersonZ) // 멤버쉽 트레이닝을 갑니다 신남!
doSomethingWithSwitch(someone: mike) // 멤버쉽 트레이닝을 갑니다 신남!
doSomethingWithSwitch(someone: jenny) // 등교를 합니다
doSomethingWithSwitch(someone: yagom) // 숨을 쉽니다

-
func doSomething(someone: PersonZ) {
    if let universityStudent = someone as? UniversityStudent {  // switch 대신 if-let을 쓰면 as?를 통해 casting 함과 동시에 unwrapping (옵셔널 추출)해서 값을 가져올 수 있다.
        universityStudent.goToMT()
    } else if let student = someone as? Student {
        student.goToSchool()
    } else if let personZ = someone as? PersonZ {
        personZ.breath()
    }
}

doSomething(someone: mike as PersonZ) // 멤버쉽 트레이닝을 갑니다 신남!
doSomething(someone: mike) // 멤버쉽 트레이닝을 갑니다 신남!
doSomething(someone: jenny) // 등교를 합니다
doSomething(someone: yagom) // 숨을 쉽니다
