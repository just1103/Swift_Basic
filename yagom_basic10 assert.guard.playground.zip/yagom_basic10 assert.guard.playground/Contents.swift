protocol Readable {  // super1
    func read()
}
protocol Writeable {  // super2
    func write()
}

protocol ReadSpeakable: Readable {  // sub1 - 단일상속
    func speak()  // func read() 기능을 따로 정의하지 않아도 사용 가능 (상속 받았으므로)
}
protocol ReadWriteSpeakable: Readable, Writeable {  // sub2 - 다중상속
    func speak()  // func read(), write() 사용 가능 (상속 받았으므로)
}


class SuperClass: Readable {
    func read() {print("read 기능 실행")}
}

class SubClass: SuperClass, Writeable, ReadSpeakable {
//    func read() {}  // override 하거나 삭제해야 한다.
    func write() {print("write 기능 실행")}
    func speak() {print("speak 기능 실행")}
}


let sup = SuperClass()
let sub = SubClass()

var someAny: Any = SuperClass()
someAny is Readable
someAny is ReadSpeakable

someAny = SubClass()
someAny is Readable
someAny is ReadSpeakable


someAny = sup

if let check = someAny as? Readable {
    check.read()
}

if let check = someAny as? ReadSpeakable {
    check.speak()  // 기능 안함
}


someAny = sub

if let check = someAny as? Readable {
    check.read()
}

if let check = someAny as? ReadSpeakable {
    check.speak()  // 기능함
}

//

protocol Togglable {
    mutating func toggle()
}

enum OnOffSwitch: Togglable {
    case off, on
    mutating func toggle() {
        switch self {
        case .off:
            self = .on
        case .on:
            self = .off
        }
    }
}
var lightSwitch = OnOffSwitch.off
lightSwitch.toggle()
// lightSwitch is now equal to .on
