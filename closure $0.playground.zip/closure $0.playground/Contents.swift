func calculate (a: Int, b: Int, method: (Int, Int) -> Int) -> Int {
    return method(a,b)
}

var result: Int
result = calculate(a: 1, b: 0, method: { (left: Int, right: Int) -> Int in
    return left + right
})
print(result)

// 1. 후행 클로저 외부 구현

result = calculate(a: 2, b: 0) { (left: Int, right: Int) -> Int in
    return left + right
}
print(result)

// 2. 타입 생략

result = calculate(a: 3, b: 0, method: { (left: Int, right: Int) in
    return left + right
})
print(result)

result = calculate(a: 4, b: 0, method: { (left, right) -> Int in
    return left + right
})
print(result)

result = calculate(a: 5, b: 0, method: { (left, right) in
    return left + right
})
print(result)


// 1+2

result = calculate(a: 3, b: 0) { (left: Int, right: Int) in
    return left + right
}
print(result)

result = calculate(a: 4, b: 0) { (left, right) -> Int in
    return left + right
}
print(result)

result = calculate(a: 5, b: 0) { (left, right) in
    return left + right
}
print(result)

// 3. 단축인자 이름 ($0), 4. return 생략

result = calculate(a: 6, b: 0, method: {
    $0 + $1
})
print(result)

// 1~4

result = calculate(a: 7, b: 0) {
    $0 + $1
}
print(result)
