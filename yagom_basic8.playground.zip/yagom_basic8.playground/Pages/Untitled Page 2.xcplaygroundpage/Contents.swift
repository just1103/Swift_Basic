// inheritance - property observer test #2

class Money {
    var currencyRate: Double = 1100    // 프로퍼티 감시자 사용 -> 삭제

    var dollar: Double = 0 {   // 프로퍼티 감시자 사용
        willSet {   // willSet의 암시적 매개변수 이름 newValue (willSet(parameter)에서 parameter 지정하지 않은 경우)
            print("\(dollar)달러에서 \(newValue)달러로 변경될 예정입니다")
        }
        didSet {    // didSet의 암시적 매개변수 이름 oldValue
            print("\(oldValue)달러에서 \(dollar)달러로 변경되었습니다")
        }
    }

    var won: Double {   // 연산 프로퍼티
        get {
            return dollar * currencyRate
        }
        set {
            dollar = newValue / currencyRate
        }
     // willSet {}   // 프로퍼티 감시자는 저장 프로퍼티에만 사용 가능 (연산 프로퍼티에는 불가)
     // didSet {}
    }
}

class subClassMoney: Money {
    override var currencyRate: Double {   // 프로퍼티 감시자 사용
        willSet(newRate) {   // willSet : 변경 직전에 호출됨
            print("override - 환율이 \(currencyRate)에서 \(newRate)으로 변경될 예정입니다")
        }
        didSet(oldRate) {   // didSet : 변경 직후에 호출됨
            print("override - 환율이 \(oldRate)에서 \(currencyRate)으로 변경되었습니다")
        }
    }
}

var moneyInMyPocket = Money()

moneyInMyPocket.currencyRate = 1150
// subclass에 프로퍼티 감시자가 있고, superclass에 없으면 -> superclass 인스턴트의 해당 프로퍼티 값이 변경될 때 프로퍼티 감시자가 호출되지 않는다.

moneyInMyPocket.dollar = 10
// 0.0달러에서 10.0달러로 변경될 예정입니다
// 0.0달러에서 10.0달러로 변경되었습니다

print(moneyInMyPocket.won)  // 11500.0
print("test")

var moneyInSubClass = subClassMoney()

moneyInSubClass.currencyRate = 3000
// 출력값 - ****
//override - 환율이 1100.0에서 3000.0으로 변경될 예정입니다
//override - 환율이 1100.0에서 3000.0으로 변경되었습니다
// *superclass의 인스턴스에 영향을 받지 않고, superclass의 default 값을 oldValue로 받아옴 (왜지?)

moneyInSubClass.dollar = 20
// 출력값 -
//0.0달러에서 20.0달러로 변경될 예정입니다
//0.0달러에서 20.0달러로 변경되었습니다
// *superclass의 인스턴스에 영향을 받지 않고, superclass의 default 값을 oldValue로 받아옴 (왜지?)

print(moneyInSubClass.won)


