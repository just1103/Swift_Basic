class Vehicle {
    var age: Int = 100
    var numberOfWheels = 0
    var description: String {
        return "\(numberOfWheels) wheel(s)"
    }
}

let vehicle = Vehicle()
print("Vehicle: \(vehicle.description)") // Vehicle: 0 wheel(s)

class Bicycle: Vehicle {  // subclass에서 superclass의 initializer를 override 합니다.
    override init() {
        super.init()  // subclass의 전체 프로퍼티에 대한 초기값을 말하는 건가???
        numberOfWheels = 2
    }
}

let bicycle = Bicycle()
print("Bicycle: \(bicycle.description)") // Bicycle: 2 wheel(s)

print(bicycle.age)

class Hoverboard: Vehicle {
    var color: String
    init(color: String) {
        self.color = color   // super.init() implicitly called here
    }
    override var description: String {
        return "\(super.description) in a beautiful \(color)"
    }
}

// var jam = Hoverboard()  // 오류 발생 왜지?
var jamjam = Hoverboard(color: "red")
