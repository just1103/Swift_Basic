// inheritance - property observer test

class Money {
    var currencyRate: Double = 1100 {   // 프로퍼티 감시자 사용
        willSet(newRate) {   // willSet : 변경 직전에 호출됨
            print("환율이 \(currencyRate)에서 \(newRate)으로 변경될 예정입니다")
        }
        didSet(oldRate) {   // didSet : 변경 직후에 호출됨
            print("환율이 \(oldRate)에서 \(currencyRate)으로 변경되었습니다")
        }
    }

    var dollar: Double = 0 {   // 프로퍼티 감시자 사용
        willSet {   // willSet의 암시적 매개변수 이름 newValue (willSet(parameter)에서 parameter 지정하지 않은 경우)
            print("\(dollar)달러에서 \(newValue)달러로 변경될 예정입니다")
        }
        didSet {    // didSet의 암시적 매개변수 이름 oldValue
            print("\(oldValue)달러에서 \(dollar)달러로 변경되었습니다")
        }
    }

    var won: Double {   // 연산 프로퍼티
        get {
            return dollar * currencyRate
        }
        set {
            dollar = newValue / currencyRate
        }
     // willSet {}   // 프로퍼티 감시자는 저장 프로퍼티에만 사용 가능 (연산 프로퍼티에는 불가)
     // didSet {}
    }
}

class subClassMoney: Money {
    override var currencyRate: Double {   // 프로퍼티 감시자 사용
        willSet(newRate) {   // willSet : 변경 직전에 호출됨
            print("override - 환율이 \(currencyRate)에서 \(newRate)으로 변경될 예정입니다")
        }
        didSet(oldRate) {   // didSet : 변경 직후에 호출됨
            print("override - 환율이 \(oldRate)에서 \(currencyRate)으로 변경되었습니다")
        }
    }
}

var moneyInMyPocket = Money()

moneyInMyPocket.currencyRate = 1150
// 환율이 1100.0에서 1150.0으로 변경될 예정입니다 <- 동일한 currencyRate 이지만 다른 값이 나옴 (willSet은 변경 직전 값)
// 환율이 1100.0에서 1150.0으로 변경되었습니다   <- 동일한 currencyRate 이지만 다른 값이 나옴  (didSet은 변경 직후 값)

moneyInMyPocket.dollar = 10
// 0.0달러에서 10.0달러로 변경될 예정입니다
// 0.0달러에서 10.0달러로 변경되었습니다

print(moneyInMyPocket.won)  // 11500.0
print("test")

var moneyInSubClass = subClassMoney()

moneyInSubClass.currencyRate = 3000
// 출력값 -
//override 환율이 1100.0에서 3000.0으로 변경될 예정입니다
//환율이 1100.0에서 3000.0으로 변경될 예정입니다
//환율이 1100.0에서 3000.0으로 변경되었습니다
//override 환율이 1100.0에서 3000.0으로 변경되었습니다
// *superclass의 인스턴스에 영향을 받지 않고, superclass의 default 값을 oldValue로 받아옴 (왜지?)
// *인스턴스의 프로퍼티 값이 변경되어 프로퍼티 감시자가 작동할 때, superclass 및 subclass에 속한 감시자가 둘다 호출됨 (순서는 뭐지? override 했는데 superclass의 프로퍼티 감시자는 왜 작동하지???)

moneyInSubClass.dollar = 20
// 출력값 -
//0.0달러에서 20.0달러로 변경될 예정입니다
//0.0달러에서 20.0달러로 변경되었습니다
// *superclass의 인스턴스에 영향을 받지 않고, superclass의 default 값을 oldValue로 받아옴 (왜지?)

print(moneyInSubClass.won)


// initializer

class PersonC {
    var name: String
    var age: Int
    var nickname: String?
   
    init(name: String, age: Int){
        self.name = name
        self.age = age
    }
}


let kevin = PersonC(name: "kevin", age: 30)
print(kevin.name)
print(kevin.age)
print(kevin.nickname)  // nil 출력


let mike = PersonC(name: "mike", age: 20)
print(mike.name)
print(mike.age)
// print(mike.nickname) // Optional("momo") 출력

// !

class Puppy {
    var name: String
    var owner: PersonC!
    
    init(name: String) {
        self.name = name
    }
    
    func goOut() {
        print("강아지 \(name)가 주인 \(owner.name)와 산책을 합니다")
    }
    
}

var max: Puppy = Puppy(name: "max")
//max.goOut()
max.owner = kevin
max.goOut()

// fail init?

class PersonD {
    var name: String
    var age: Int
    var nickname: String?
    
    init?(name:String, age:Int){
        
        if (0...120).contains(age) == false {
                    return nil
        }
   
    self.name = name
    self.age = age
    }
}

let john: PersonD? = PersonD(name: "john", age: 30)
let jocker: PersonD? = PersonD(name: "jocker", age: 130)

print(john)  // Optional(__lldb_expr_52.PersonD) ???
print(jocker)  // nil 출력


// deinit

class PersonE {
    var name: String
    var pet: Puppy?
    var child: PersonC
    
    init(name: String, child: PersonC) {
        self.name = name
        self.child = child
    }
    
    deinit {
        if let petName = pet?.name {  // 일반적인 optional을 unwrapping 해주는 Optional binding (if let 구문)
            print("\(name)가 \(child.name)에게 \(petName)를 인도합니다")
            self.pet?.owner = child
        }
        
    }
}

var donald: PersonE? = PersonE(name: "donald", child: kevin)
donald?.pet = max
print(donald?.name)
donald = nil


// test

struct Color {
    let red, green, blue: Double
    init(red: Double, green: Double, blue: Double) {
        self.red   = red
        self.green = green
        self.blue  = blue
    }
    init(white: Double) {
        red   = white
        green = white
        blue  = white
    }
}

let magenta = Color(red: 1.0, green: 0.0, blue: 1.0)
let halfGray = Color(white: 0.5)

print(magenta.red)
print(halfGray.green)
print(halfGray.red)

// L/G

class Food {
    var name: String
    init(name: String) {
        self.name = name
    }
    convenience init() {
        self.init(name: "[Unnamed]")
    }
}

let instance1 = Food()  // 가능 (convenience init의 parameter가 없으므로)
let instance2 = Food(name: "namename")

let namedMeat = Food(name: "Bacon")  // namedMeat's name is "Bacon"

let mysteryMeat = Food()  // mysteryMeat's name is "[Unnamed]"

class RecipeIngredient: Food {
    var quantity: Int
    init(name: String, quantity: Int) {  // init 정의 (override init이 아니라?)
        self.quantity = quantity
        super.init(name: name)
    }
    override convenience init(name: String) {  // superclass의 convenience init을 override 했음
        self.init(name: name, quantity: 1)
    }
}

let oneMysteryItem = RecipeIngredient()
let oneBacon = RecipeIngredient(name: "Bacon")
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)

// enum initializer

enum TemperatureUnit {
    case kelvin, celsius, fahrenheit
    init?(symbol: Character) {  // symbol을 왜 따로 선언을 안해주지?
        switch symbol {
        case "K":
            self = .kelvin
        case "C":
            self = .celsius
        case "F":
            self = .fahrenheit
        default:
            return nil
        }
    }
}


