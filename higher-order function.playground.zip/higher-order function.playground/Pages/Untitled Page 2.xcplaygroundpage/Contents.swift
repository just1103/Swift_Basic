// filter
var numbers = [0,1,2,3,4]

// 1. for

var filtered = [Int]()

for i in numbers {
    if i % 2 == 0 {
        filtered.append(i)
    }
}
print(filtered)
// [0, 2, 4]

// 2. filter

let evenNumbers: [Int] = numbers.filter({ (i: Int) -> Bool in
    return i % 2 == 0
})
print(evenNumbers)
// [0, 2, 4]

let evenNumbers1: [Int] = numbers.filter {
    $0 % 2 == 0
}
print(evenNumbers1)

let oddNumbers: [Int] = numbers.filter {
    $0 % 2 != 0   // 결과값을 변수 oddNumbers 에 반환
}
print(oddNumbers)
