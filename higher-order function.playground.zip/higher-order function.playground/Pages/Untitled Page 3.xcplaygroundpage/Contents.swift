// reduce

// 기존 데이터 -> 모든 요소를 더하는 기능 구현
let someNumbers: [Int] = [2, 8, 15]


// 방법1 - for 문 사용
var result: Int = 0  // reduce와 달리 let 선언 불가

for number in someNumbers {
    result += number
}
print(result) // 25

// 방법2 - reduce 사용

let sum: Int = someNumbers.reduce(0, {(left: Int, right: Int) -> Int in
    print("\(left) + \(right)")
    return left + right
})

//0 + 2
//2 + 8
//10 + 15

print(sum)  // 25

let subtract: Int = someNumbers.reduce(0, { (left: Int, right: Int) -> Int in
    print("\(left) - \(right)")
    return left - right
})

//0 - 2
//-2 - 8
//-10 - 15

print(subtract)  // -25

// 방법3

let sumFromThree: Int = someNumbers.reduce(3) {
    $0 + $1
}

print(sumFromThree) // 28
