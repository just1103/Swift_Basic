// map

var numbers: [Int] = [0,1,2,3,4]

var doubledNumbers = [Int]()
var stringedNumbers = [String]()

//방법1 - for statement 사용
//
//for i in numbers {
//    doubledNumbers.append(i * 2)
//    stringedNumbers.append("\(i)")
//}
//
//print(doubledNumbers)
//print(stringedNumbers)
//[0, 2, 4, 6, 8]
//["0", "1", "2", "3", "4"]

//방법2 - map 사용

//doubledNumbers = numbers.map({ (i: Int) -> Int in
//    return i * 2
//})
//
//stringedNumbers = numbers.map({ (i: Int) -> String in
//    return "\(i)"
//})
//
//print(doubledNumbers)
//print(stringedNumbers)
//[0, 2, 4, 6, 8]
//["0", "1", "2", "3", "4"]

//방법3 - map + closure 표현방법

doubledNumbers = numbers.map({
    return $0 * 2
})

stringedNumbers = numbers.map({
    return "\($0)"
})

print(doubledNumbers)
print(stringedNumbers)
//[0, 2, 4, 6, 8]
//["0", "1", "2", "3", "4"]
