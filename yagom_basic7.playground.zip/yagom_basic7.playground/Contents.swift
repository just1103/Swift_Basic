class Student {
    var name: String = "unknown"  // 인스턴트 저장 프로퍼티
    
    static var storedProperty: Int = 10  // 타입 저장 프로퍼티
    
    func selfIntroduce() {  // 인스턴스 메서드
        print("저는 \(name)입니다")
    }

    final func finalMethod() {  // 인스턴스 메서드
        print("finalMethod 입니다")
    }

    static func typeMethodStatic() {  // 타입 메서드 - static
        print("static type method")
    }
   
    class func typeMethodClass() {  // 타입 메서드 - class (override 가능)
        print("class type method")
    }
    
    final class func finalTypeMethodClass() {  // 타입 메서드 - class (override 가능)
        print("final - class type method")
    }
}

class University: Student {
    var major: String = "major0"
    
    override func selfIntroduce() {
        print("저는 \(name) 이고, 전공은 \(major) 입니다.")
    }
    
    override class func typeMethodClass() {
        print("override class type method")
    }
}

// child class

University.typeMethodClass()  // child class의 타입 메서드 (부모 class의 타입 메서드를 override 했던)

var kevin: University = University()
kevin.name = "kevin"
kevin.major = "computer science"
kevin.selfIntroduce()
kevin.finalMethod()  // 부모 class의 인스턴스 메서드 호출해보기


// parent class

// 타입 프로퍼티 확인
print(Student.storedProperty) // 10

// 타입 메서드 사용
Student.typeMethodStatic() // static type method - 출력
Student.typeMethodClass() // class type method - 출력
Student.finalTypeMethodClass() // final - class type method

// var선언 인스턴스 생성
var yagom: Student = Student()
yagom.name = "yagom"
yagom.selfIntroduce() // 저는 yagom입니다
yagom.finalMethod() // finalMethod 입니다

// let선언 인스턴스 생성
let jina: Student = Student()
jina.name = "jina"    // let선언 인스턴스이지만 가변 프로퍼티는 수정가능하다! (Structure와 다름)
jina.selfIntroduce()  // 저는 jina입니다 - 출력 (Structure에서는 unknown)

yagom.selfIntroduce()  // 저는 yagom입니다

// inheritance - property observer test

class Money {
    var currencyRate: Double = 1100 {   // 프로퍼티 감시자 사용
        willSet(newRate) {   // willSet : 변경 직전에 호출됨
            print("환율이 \(currencyRate)에서 \(newRate)으로 변경될 예정입니다")
        }
        didSet(oldRate) {   // didSet : 변경 직후에 호출됨
            print("환율이 \(oldRate)에서 \(currencyRate)으로 변경되었습니다")
        }
    }

    var dollar: Double = 0 {   // 프로퍼티 감시자 사용
        willSet {   // willSet의 암시적 매개변수 이름 newValue (willSet(parameter)에서 parameter 지정하지 않은 경우)
            print("\(dollar)달러에서 \(newValue)달러로 변경될 예정입니다")
        }
        didSet {    // didSet의 암시적 매개변수 이름 oldValue
            print("\(oldValue)달러에서 \(dollar)달러로 변경되었습니다")
        }
    }

    var won: Double {   // 연산 프로퍼티
        get {
            return dollar * currencyRate
        }
        set {
            dollar = newValue / currencyRate
        }
     // willSet {}   // 프로퍼티 감시자는 저장 프로퍼티에만 사용 가능 (연산 프로퍼티에는 불가)
     // didSet {}
    }
}

var moneyInMyPocket = Money()

moneyInMyPocket.currencyRate = 1150
// 환율이 1100.0에서 1150.0으로 변경될 예정입니다 <- 동일한 currencyRate 이지만 다른 값이 나옴 (willSet은 변경 직전 값)
// 환율이 1100.0에서 1150.0으로 변경되었습니다   <- 동일한 currencyRate 이지만 다른 값이 나옴  (didSet은 변경 직후 값)

moneyInMyPocket.dollar = 10
// 0.0달러에서 10.0달러로 변경될 예정입니다
// 0.0달러에서 10.0달러로 변경되었습니다

print(moneyInMyPocket.won)  // 11500.0
