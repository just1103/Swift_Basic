var someInt: Int = 0

assert(someInt == 0, "someInt != 0")

someInt = 1

//assert(someInt == 0)
//assert(someInt == 0, "someInt != 0")

//

func funcWithAssert(age: Int?) {
    
    assert(age != nil, "age가 nil 입니다")
    assert(age! >= 0 && age! <= 130, "age가 잘못 입력되었습니다")
    print("age가 \(age!) 입니다")
    
}

funcWithAssert(age: 30)
//funcWithAssert(age: nil)
//funcWithAssert(age: 500)

//

func funcWithGuard (age: Int?) {
    guard let unwrappedAge = age,
          unwrappedAge >= 0, unwrappedAge <= 130 else {
        print("age가 잘못 입력되었습니다")
        return
    }
    print("Your age is \(unwrappedAge)")
}

funcWithGuard(age: 50)  // Your age is 50
funcWithGuard(age: 500)  // age가 잘못 입력되었습니다

var count: Int = 1

while true {
    guard count < 3 else {
        break
    }
    print(count)
    count += 1
}

func someFunc(info: [String:Any]) {
    guard let name = info["name"] as? String else {
        return
    }
    
    guard let age = info["age"] as? Int, age >= 0 else {
        return
    }
    
    print("My name is \(name), My age is \(age)")
}

someFunc(info: ["name":"jenny","age":20])
someFunc(info: ["name":"jenny","age":1000])
someFunc(info: ["name":"jenny","age":-100])
someFunc(info: ["name":"jenny","age":"20"])
someFunc(info: ["name":"jenny"])

//
