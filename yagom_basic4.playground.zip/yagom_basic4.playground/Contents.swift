import UIKit

class Student {
    var name: String = "unknown"
    var `class`: String = "Swift"
    
    class func selfIntro() {
        print("Student type의 class이다")
    }
    
    func selfIntro() {
        print("저는 \(self.class)반의 \(name)입니다")
    }
}

Student.selfIntro()

var yagom: Student = Student()
yagom.name = "yagom"
yagom.class = "스위프트"
yagom.selfIntro()

let jina: Student = Student()
jina.name = "jina"
jina.selfIntro()

let firstClassReference = Student()
var secondClassReference = firstClassReference
secondClassReference.name = "new"

print(firstClassReference.name)
print(secondClassReference.name)

// quiz 1

struct aStruct {
    var aProperty: String = "Property"
}

var aInstance = aStruct()  // 구조체 인스턴스 생성

func aFunction(structInstance: aStruct){   // 이 함수의 parameter는 구조체 aStruct 타입임
    var localVar: aStruct = structInstance // 인스턴스를 변수로 가져와서
    localVar.aProperty = "ABC"             // 그 인스턴스의 프로퍼티를 수정해줌 (값이 복사된 변수의 프로퍼티가 수정된 것)
    print(aInstance.aProperty)             // (확인용) 그래봤자 aInstance의 프로퍼티는 수정되지 않음
}

aFunction(structInstance: aInstance)
print(aInstance.aProperty)  // Property 출력

// quiz 2

class aClass {
    var aProperty: String = "Property"
}

var aInstance2 = aClass()

func aFunction2(classInstance: aClass){
    var localVar: aClass = classInstance
    localVar.aProperty = "ABC"
    print(aInstance2.aProperty)
}

aFunction2(classInstance: aInstance2)
print(aInstance2.aProperty)


// closure

func sumFunction (a: Int, b: Int) -> Int {
    return a+b
}

var resultSum: Int = sumFunction(a: 1, b: 2)

print(resultSum)

// closure을 변수에 할당

var sum: (Int, Int) -> Int = { (a: Int, b: Int) -> Int in
    return a+b
}

resultSum = sum(3,4)

print(resultSum)

// closure를 할당했던 변수에 다시 함수를 할당해줄 수도 있다.

sum = sumFunction(a:b:)

resultSum = sum(5,6)

print(resultSum)


