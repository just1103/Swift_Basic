
struct Point {
    var x = 0.0, y = 0.0
}

struct Size {
    var width = 0.0, height = 0.0
}

struct Rect {
    var origin = Point()
    var size = Size()
    var center: Point {
        get {
            let centerX = origin.x + (size.width / 2)
            let centerY = origin.y + (size.height / 2)
            return Point(x: centerX, y: centerY)
        }
        
        set {
            origin.x = newValue.x - (size.width / 2)
            origin.y = newValue.y - (size.height / 2)
        }
    }
}

var square = Rect()
square.origin = Point(x: 0.0, y: 0.0)
square.size = Size(width: 10.0, height: 10.0)
print(square.center)

square.center = Point(x: 15.0, y: 15.0)
print(square.origin.x)
print(square.origin.y)

