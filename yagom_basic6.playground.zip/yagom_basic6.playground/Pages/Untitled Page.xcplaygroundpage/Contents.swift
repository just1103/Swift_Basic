import UIKit

// computed property

struct Point {
    var x = 0.0, y = 0.0  // 저장 var 프로퍼티
}

struct Size {
    var width = 0.0, height = 0.0  // 저장 var 프로퍼티
}

struct Rect {
    var origin = Point()
    var size = Size()
    var center: Point {  // *연산 var 프로퍼티
        get {
            let centerX = origin.x + (size.width / 2)
            let centerY = origin.y + (size.height / 2)
            return Point(x: centerX, y: centerY)  // *다른 프로퍼티들의 값을 활용하여 연산한 결과값을 return 해준다.
        }
     // get { // (Shorthand) 구조체 Point의 parameter 프로퍼티 값을 single expression으로 한번에 할당해줄 수 있다. return 생략 가능하다.
     //     Point(x: origin.x + (size.width / 2),
     //           y: origin.y + (size.height / 2))
     //      }
        
        set (newCenter) {
            origin.x = newCenter.x - (size.width / 2)  // *새로운 Point 값이 입력되면 연산한 결과값을 다른 프로퍼티에 할당해준다.
            origin.y = newCenter.y - (size.height / 2)
        }
     // set { // (Shorthand) setter의 parameter (ex. set (newCenter))를 별도 지정하지 않을 경우 <newValue>를 암시적 parameter로 사용한다.
     //     origin.x = newValue.x - (size.width / 2)
     //     origin.y = newValue.y - (size.height / 2)
     // }
        
    }
}

var square = Rect()  // Rect에 대한 인스턴트 생성
square.origin = Point(x: 0.0, y: 0.0)  // origin 프로퍼티 할당 (즉, 구조체 Point의 저장 프로퍼티 값을 할당)
square.size = Size(width: 10.0, height: 10.0)  // size 프로퍼티 할당 (즉, 구조체 Size의 저장 프로퍼티 값을 할당)
print(square.center)  // Point(x: 5.0, y: 5.0) - 출력

//var square = Rect(origin: Point(x: 0.0, y: 0.0),   // 한꺼번에 이렇게도 가능 (동일한 결과)
//                  size: Size(width: 10.0, height: 10.0))

let initialSquareCenter = square.center
square.center = Point(x: 15.0, y: 15.0)  // 구조체 Rect의 center 프로퍼티 - set (newCenter) 부분에 들어가는 새로운 Point 값!!! (15-5=10)
print("square.origin is now at (\(square.origin.x), \(square.origin.y))")


// read-only computated property

struct Cuboid {
    var width = 0.0, height = 0.0, depth = 0.0
    var volume: Double {
        return width * height * depth
    }
}

let fourByFiveByTwo = Cuboid(width: 4.0, height: 5.0, depth: 2.0)
print("the volume of fourByFiveByTwo is \(fourByFiveByTwo.volume)")

// test

struct Student {
    var name: String = "unkown"   // 인스턴스 저장 프로퍼티 (구조체 내부의 변수: 프로퍼티, 구조체 내부의 함수: 메소드)
    var `class`: String = "Swift"
    var koreanAge: Int = 0
    
    var westernAge: Int {   // *인스턴스 연산 프로퍼티
        get {  // *koreanAge에서 -1 연산한 값을 westernAge에 return 해준다.
            return koreanAge - 1
        }
        
        set(inputValue) {  // *inputValue를 저장하는 것이 아니라, 해당 값을 +1 연산해서 koreanAge에 할당해준다.
            koreanAge = inputValue + 1
        }
    }
    
    static var typeDescription: String = "학생"   // 타입 저장 프로퍼티

    // func selfIntroduce() {    // 인스턴스 메서드 - parameter와 반환값이 없는
    //    print("저는 \(self.class)반 \(name)입니다")
    // }
    
    // 위의 selfIntroduce() 메서드를 대체할 수 있습니다. *get만 있고 set 없음: 읽기전용
    var selfIntroduction: String {
        get {
            return "저는 \(self.class)반 \(name)입니다"
        }
    }

    // static func selfIntroduce() {     // 타입 메서드
    // print("학생타입입니다")
    // }
    
    // 읽기전용에서는 get을 생략할 수 있다.
    static var selfIntroduction: String {     // 읽기전용 타입 연산 프로퍼티
        get { return "학생타입입니다" }
    }
}

print(Student.selfIntroduction)  // 타입 연산 프로퍼티 사용
// 학생타입입니다 - 출력

var yagom: Student = Student()  // 인스턴스 생성
yagom.koreanAge = 10
yagom.name = "yagom"  // 인스턴스 저장 프로퍼티 사용
print(yagom.name) // yagom - 출력

print(yagom.selfIntroduction)  // 인스턴스 연산 프로퍼티 사용
// 저는 Swift반 yagom입니다 - 출력

print("제 한국나이는 \(yagom.koreanAge)살이고, 미쿡나이는 \(yagom.westernAge)살입니다.")
// 제 한국나이는 10살이고, 미쿡나이는 9살입니다.

yagom.westernAge = 100
print(yagom.koreanAge)

// property observer

struct Money {
    var currencyrate: Double = 1100 {
        willSet (newRate) {
            print("환율이 \(currencyrate)에서 \(newRate)으로 변경될 예정입니다!")
        }
        didSet (oldRate) {
            print("환율이 \(oldRate)에서 \(currencyrate)으로 변경되었습니다!")
        }
    }
    
    var dollar: Double = 0 {
        willSet {
            print("\(dollar) 달러에서 \(newValue) 달러로 변경될 예정입니다!")
        }
        didSet {
            print("\(oldValue) 달러에서 \(dollar) 달러로 변경되었습니다!")
        }
    }
    
    var won: Double {
        get {
            return dollar * currencyrate
        }
        set {
            dollar = newValue / currencyrate
        }
    }
}

var moneyInMyPocket = Money()
moneyInMyPocket.currencyrate = 1100
moneyInMyPocket.dollar = 10
print(moneyInMyPocket.won)

// L/G Example

class StepCounter {
    var totalStep: Int = 0 {
        willSet {
            print("About to set totalStep to \(newValue)")
        }
        didSet {
            if totalStep > oldValue {
                print("\(totalStep - oldValue) steps are add!")
            }
        }
    }
        
}

var newStep = StepCounter()
newStep.totalStep = 100
newStep.totalStep = 900

//

let initializedDictionary: [String: String] = ["name": "yagom", "gender": "male"]


let someValue: String? = initializedDictionary["name"]

// inherit




