import UIKit

var integers = [1, 2, 3]  // Int type의 Array
let people = ["yagom": 10, "eric": 15, "mike": 12]  // String, Int type의 Dictionary

for item1 in integers {
    print(item1)
}

for (name, age) in people {
    print("\(name) : \(age)")
}

print(integers)

while integers.count > 10 {
    integers.removeLast()
}

print(integers)

/*
repeat {
    integers.removeLast()
} while integers.count > 10
print(integers)
 */

for index in 1...5 {
    print("\(index) times five is \(5*index)")
}

let someConstant: Int
// someConstant = nil

let someCons1: Int?
someCons1 = nil

func someFunc(parameter1: Int?){
    //
}

func someFunc1(parameter1: Int){
    //
}

someFunc(parameter1: nil)

// ! : Implicitly Unwrappted Optional

var optionalValue: Int! = 100
optionalValue = optionalValue + 1
optionalValue = nil
// optionalValue = optionalValue + 100

switch optionalValue {
case .none:
    print("This Optional Variable is nil")
case .some(let value):
    print("This Optional's value is \(value)")
}

// optional unwrapping

func printName0(_ name: String){
    print(name)
}

var myName0: String? = "J"
var nameTest: String! = "OK"

// printName(name: "A")   // 오류 발생
printName0("B")  // B 출력

// printName0(myName)
printName0(nameTest) // ! 이라서 가능

var myName: String? = nil

if let name: String = myName {
    print(name)
} else {
    print("myName == nil")
}

myName = "change"

var yourName: String! = "Yagom"
// yourName = nil

if let name: String = myName, let friend: String = yourName {
    print("\(name) and \(friend) are together!")
}

// 강제 추출

printName0(myName!)

printName0(yourName) // ! 타입이라 가능

myName = nil

// printName0(myName)

printName0(yourName!)
printName0(yourName)


yourName = nil

// print(yourName)

var integers1 = Array<Int>()
integers1 = [1,2,3]

var integers2 = [Int]()
integers2 = [4,5,6]

var integers3 = [1,2,3]
integers3 = [4,5,6]
// integers3 = [1.2, 2.3, 4.5]


// var integers4 = []

var anyDictionary1 = Dictionary<String, Any>()
anyDictionary1 = ["hj":21, "mj":20]

var anyDictionary2 = [String: Any]()
anyDictionary2 = ["hj":"why", "mj":"where"]

// var anyDicyionary3 = [:]

var integerSet: Set<Int> = Set<Int>()
integerSet.insert(1)  // *요소 추가 method
integerSet.insert(100)
integerSet.insert(99)
integerSet.insert(99)
integerSet.insert(99) // set는 중복된 데이터는 추가 저장하지 않는다.

integerSet // -> {100,99,1}
integerSet.contains(1) // -> true
integerSet.contains(2) // -> false

integerSet.remove(100)   // 100 삭제
integerSet.removeFirst() // 99 삭제 (???순서가 없다며)

integerSet.count


// 집합 개념으로 접근하기
let setA: Set<Int> = [1,2,3,4,5]  // {3,4,2,1,5} 왜 [] 형태로 입력하지? Set 니까 {} 형태로 할당이 될텐데??? [Array]가 {Set}에 들어가면 순서가 없어지는건가?

print(setA)
let setB: Set<Int> = [3,4,5,6,7]  // {6,3,4,5,7}
// let setC: Set<Int> = {1,2,3,4,5}  // 오류 발생 -> 왜?

// 합집합
let union: Set<Int> = setA.union(setB) // {4,1,3,2,6,7,5}
print(union) // "[4, 1, 3, 2, 6, 7, 5]\n"

// 동일한 타입의 Array로 변환하는 method
let sortedUnion: [Int] = union.sorted() // [1,2,3,4,5,6,7]
// let sortedUnion: Array<Int> = union.sorted()
print(union) // "[4, 1, 3, 2, 6, 7, 5]\n"

// 교집합
let intersection: Set<Int> = setA.intersection(setB) // {5,3,4}
print(intersection) // "[5, 4, 3]\n"

// 차집합
let subtracting: Set<Int> = setA.subtracting(setB) // {2,1}
print(subtracting) // "[2, 1]\n"


// Quiz3

func addOne(left a: Int, right b: Int) -> Int {
     return a + b
}

addOne(left: 1, right: 2)

// addOne(a: 1, b: 2)  //

func greeting(to friend: String, from me: String) {
     print("Hello \(friend)! I'm \(me)")
}

let optionalFour: Int! = nil
let optionalOOOne: Int? = optionalFour

var optionalA: Int? = nil
var optionalB: Int! = nil

optionalB = optionalA

var int100 = 100
var double100 = 100.1

double100 = double100 + Double(int100) + 0.8

int100 = Int(double100)

// tuple

let http200Status = (statusCode: 200, description: "OK")

print(http200Status.0)  // prints 200

print(http200Status.description)  // prints OK

let possibleNumber = "123"
let convertedNumber = Int(possibleNumber)
print(convertedNumber as Any)

var arrayABC: [Int] = []

// if arrayABC == nil {   // empty와 nil은 다름 (Int 타입은 nil이 할당될 수 없음)
//    print("array가 nil이 맞구나")
// }

// structure

struct Sample {
    var mutableProperty: Int = 100
    
    let immutableProperty: Int = 100
    
    static var typeProperty: Int = 100
    
    func instanceMethod() {
        print("instance Method")
    }
    
    static func typeMethod() {
        print("type Method")
    }
}

var mutable: Sample = Sample()

mutable.mutableProperty = 200

let immutable: Sample = Sample()

//immutable.mutableProperty = 200

Sample.typeProperty

struct Student {
    var name: String = "unknown"
    var `class`: String = "Swift"
    
    static func selfIntro(){
        print("Student type 입니다")
    }
    
    func selfIntro(){
        print("저는 \(self.class)반의 \(name) 입니다")
    }
}

Student.selfIntro()

var yagom: Student = Student()
yagom.name = "yagom"
yagom.selfIntro()


struct Student2 {
    var name2: String = "unknown"
    var class2: String = "Swift"
    
    static func selfIntro2(){
        print("Student type의 구조체이다")
    }
    
    func selfIntro2(){  // static func는 왜 안되지? - instance member 'name' cannot be used on type 'Student'
        print("저는 \(class2)반의 \(name2) 입니다")
    }
}

Student2.selfIntro2()

var kevin: Student2 = Student2()
kevin.name2 = "kevin"
kevin.selfIntro2()

// Class

class Sample21 {
    var mutable: Int = 100
    let immutable: Int = 100
    
    static var typeProperty: Int = 100
    
    func instanceMethod() {
        print("instance Method 이다")
    }
    
    static func typeMethod() {  // 상속시 재정의 불가
        print("type Method-static 이다")
    }
    
    class func classMethod() {  // 상속시 재정의 가능
        print("type Method-class 이다")
    }
}

var mutableReference: Sample21 = Sample21()

mutableReference.mutable = 200
// mutableReference.immutable = 200 // error

let immutableReference: Sample21 = Sample21()

immutableReference.mutable = 200
// immutableReference.immutable = 200 // error

Sample21.typeProperty = 200
Sample21.typeMethod()




